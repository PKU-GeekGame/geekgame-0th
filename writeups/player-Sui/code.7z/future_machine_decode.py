key = '.q~03QKLNSp"s6AQtEW<=MNv9(ZMYntg2N9hSe5=k'

table1 = list(range(96))
h = 114514
for i in range(1, 96):
    h = (h * 1919 + 7) % 334363
    table1[h % i], table1[i] = table1[i], table1[h % i]

table2 = list(range(41))
for i in range(1, 41):
    h = (h * 1919 + 7) % 334363
    table2[h % i], table2[i] = table2[i], table2[h % i]


def encode1(instr):
    re = [0 for _ in instr]
    for i in range(41):
        re[i] = (table1[instr[i] - 32] + i) % 96 + 32
    return re

def encode2(instr):
    re = [0 for _ in instr]
    for i in range(41):
        re[table2[i]] = instr[i]
    return re

rev1 = {j:i for i,j in enumerate(table1)}
rev2 = {j:i for i,j in enumerate(table2)}

def decode2(instr):
    re = [0 for _ in instr]
    for i in range(41):
        re[i] = instr[table2[i]]
    return re

def decode1(instr):
    re = [0 for _ in instr]
    for i in range(41):
        re[i] = rev1[(instr[i] - 32 - i) % 96] + 32
    return re

# example
instr = [x for x in key.encode()]
print(instr)
en1 = encode1(instr)
print(en1)
en2 = encode2(en1)
print(en2)
de2 = decode2(en2)
print(de2)
de1 = decode1(de2)
print(de1)

keystr = [x for x in key.encode()]
tmp2 = decode2(keystr)
tmp1 = decode1(tmp2)
result = ''.join([chr(i) for i in tmp1])
print(result)
