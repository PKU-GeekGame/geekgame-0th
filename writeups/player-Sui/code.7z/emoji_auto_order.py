import requests
from bs4 import BeautifulSoup
import random
import time
from itertools import chain

token = '(token)'
url = 'http://prob11.geekgame.pku.edu.cn'

s = requests.Session() 
r = s.post(url + '/token', data = {'token': token})
# print(r.text)

better_dict = {}
worse_dict = {}
def add_if_not_present(c):
    if c not in better_dict:
        better_dict[c] = set()
    if c not in worse_dict:
        worse_dict[c] = set()


def update(good, bad):
    # print("{} > {}".format(good, bad))
    add_if_not_present(good)
    add_if_not_present(bad)
    good_list = list(better_dict[good])
    good_list.append(good)
    bad_list = list(worse_dict[bad])
    bad_list.append(bad)
    for g in good_list:
        for b in bad_list:
            if g == b:
                print ("Error!", g, b)
            worse_dict[g].add(b)
            better_dict[b].add(g)


def get_choice(choices):
    for c in choices:
        if c in worse_dict and all([d in worse_dict[c] for d in choices if d != c]):
            return c
    return choices[random.randint(0, len(choices) - 1)]

with open('emoji_greater_than.txt') as f:
    lines = f.readlines()
    for line in lines:
        line = line.strip()
        if len(line) > 1 and '>' in line:
            arr = line.split('>')
            c = arr[0]
            if len(arr[1]) > 0:
                for d in arr[1].split(' '):
                    add_if_not_present(c)
                    add_if_not_present(d)
                    better_dict[d].add(c)
                    worse_dict[c].add(d)

progress = 0
soup = BeautifulSoup(r.content, 'html.parser')
while progress <= 20:
    time.sleep(1)
    try:
        choices = [node.get('value') for node in soup.findAll('input')]
        choice = get_choice(choices)
        print(' '.join(['[{}]'.format(c) if choice == c else c for c in choices]))
        r = s.post(url, data = {'choice': choice})
        soup = BeautifulSoup(r.content, 'html.parser')
        right = False
        right_wrong_text = soup.find('div', class_='alert').text.strip()
        right = '回答正确' in right_wrong_text
        print(right_wrong_text)
        if right:
            for c in choices:
                if c != choice:
                    update(choice, c)
        elif len(choices) == 2:
            for c in choices:
                if c != choice:
                    update(c, choice)
        progress = int(soup.find('div', class_='progress-bar').text.strip())
        print("progress: {}".format(progress))
        emoji_list = sorted(list(set(chain(worse_dict.keys(), better_dict.keys()))), key=lambda x: (-len(worse_dict[x]), ord(x[0])))
        emoji_id_map = {j:i for (i,j) in enumerate(emoji_list)}
        with open('greater_than.txt', 'w') as f:
            for c in emoji_list:
                print("{}>{}".format(c, ' '.join(sorted(list(worse_dict[c]), key=lambda x:emoji_id_map[x]))), file=f)
    except:
        print(soup)
        break


