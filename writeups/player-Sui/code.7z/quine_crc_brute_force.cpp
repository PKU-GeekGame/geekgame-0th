#include <iostream>
#include <fstream>
#include <zlib.h>
using namespace std;

int main() {
  cout << "Hello, World Again!" << endl;
  
  int dataLen = 542; 
  unsigned int indices[4] = {14, 86, 253, 408};
  char data[dataLen];
  std::ifstream fin( "quine.zip", std::ios::binary );
  fin.read(data, dataLen);
  fin.close();

  unsigned long target = 0;
  for (int i = 0; i <= 255; i += 1) {
    for (int t = 0; t < 4; t ++){
      data[indices[t] + 3] = (char) i;
    }
    cout << (int) i << endl;
    for (int j = 0; j <= 255; j += 1) {
      for (int t = 0; t < 4; t ++){
        data[indices[t] + 2] = (char) j;
      }
      for (int k = 0; k <= 255; k += 1) {
        for (int t = 0; t < 4; t ++){
          data[indices[t] + 1] = (char) k;
        }
        for (int l = 0; l <= 255; l += 1) {
          for (int t = 0; t < 4; t ++){
            data[indices[t]] = (char) l;
          }
          unsigned long crc = crc32(0L, (const unsigned char*) data, dataLen);
          if (crc == target) {
            std::ofstream fout( "fixed.zip", std::ios::binary );
            fout.write(data, dataLen);
            fout.close();
            printf("%lx\n", crc);
            return 0;
          }
          target += 1;
        }
      }
    }
  }

  return 0;
}
