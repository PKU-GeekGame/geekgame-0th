from Crypto.Cipher import AES #pip install pycryptodome aioconsole
from Crypto.Random import random
from CA import *
# from flag import flag1,flag2,A_cert,B_cert
import asyncio
import os
import aioconsole
import sys

token = '(token)'

def pad(msg):
    n = 16 - len(msg) % 16
    return msg + bytes([n]) * n

def unpad(msg):
    assert len(msg) > 0 and len(msg) % 16 ==  0
    n = msg[-1]
    assert 1 <=  n <=  16
    assert msg[-n:]  ==  bytes([n]) * n
    return msg[:-n]

# step 1: to alice and bob

gk_alice = int(input(), 16)   # message to bob
gk_bob = int(input(), 16)   # message to alice

if len(sys.argv) > 1 and sys.argv[1] == '1':
    print("flag 1")
    d = P - 1 # Fermat's Little Theorem
    pk = pow(G,d,P)
else:
    print("flag 2")
    d = random.getrandbits(1024)
    d -= d & 1
    pk = pow(G,d,P)

key_alice = pow(gk_alice,d,P)
aes_key_alice = int.to_bytes(key_alice %(2**128),16,'big')

key_bob = pow(gk_bob,d,P)
aes_key_bob = int.to_bytes(key_bob %(2**128),16,'big')

print()
print(0)
print(hex(pk)[2:])
print(1)
print(hex(pk)[2:])
print()

# step 2: get bob's CA

acmess_alice = bytes.fromhex(input())             # message to bob
baes_iv_alice, bcipher_alice = acmess_alice[:16],acmess_alice[16:]
aaes_alice = AES.new(aes_key_alice, AES.MODE_CBC, baes_iv_alice)
amess_alice = unpad(aaes_alice.decrypt(bcipher_alice)).decode()
cert_verify(amess_alice)

acmess_bob = bytes.fromhex(input())             # message to alice
baes_iv_bob,bcipher_bob = acmess_bob[:16],acmess_bob[16:]
aaes_bob = AES.new(aes_key_bob,AES.MODE_CBC,baes_iv_bob)
amess_bob = unpad(aaes_bob.decrypt(bcipher_bob)).decode()
cert_verify(amess_bob)

print("info:\n{}\n{}\n{}".format(key_alice, 2**512, key_alice < 2**512))

# step 3 : get Alice's flag

aes_iv = os.urandom(16)
aes = AES.new(aes_key_alice, AES.MODE_CBC, aes_iv)
cmess = (aes_iv+aes.encrypt(pad(amess_bob.encode()))).hex()

print()
print('0')
print(cmess)
print()

fga = input()
cflag = bytes.fromhex(fga)
civ,flagc = cflag[:16],cflag[16:]
caes = AES.new(aes_key_alice,AES.MODE_CBC,civ)
flag = unpad(caes.decrypt(flagc)).decode()
print(flag)
        
