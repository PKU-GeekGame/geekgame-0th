#include <cstddef>
#include <cstdio>
#include <cstring>

using namespace std;

bool check(long startPosition, int length)
{
	int frontAndBackIndices;

	frontAndBackIndices = 0;
	while (true)
	{
		if (length <= frontAndBackIndices)
		{
			return true;
		}
		if (*(char *)(startPosition + frontAndBackIndices) != *(char *)(startPosition + (long)(length - frontAndBackIndices) - 1))
		{
			break;
		}
		frontAndBackIndices = frontAndBackIndices + 1;
	}
	return false;
}

void run()
{
	char inputString[104];

	int stringLength;
	int indexToPrint;
	int endIndex;
	int startIndex;
	int maxLength;
	int startIndex_max;

	scanf("%s", inputString);
	stringLength = (int)strlen(inputString);

	maxLength = 0;
	startIndex = 0;
	while (startIndex < stringLength)
	{
		endIndex = startIndex + 1;
		while (endIndex <= stringLength)
		{
			if (

				check(reinterpret_cast<long>(inputString + startIndex), endIndex - startIndex) &&

				(maxLength < endIndex - startIndex))
			{
				maxLength = endIndex - startIndex;
				startIndex_max = startIndex;
			}
			endIndex = endIndex + 1;
		}
		startIndex = startIndex + 1;
	}
	indexToPrint = startIndex_max;
	while (indexToPrint < maxLength + startIndex_max)
	{
		putchar((int)inputString[indexToPrint]);
		indexToPrint = indexToPrint + 1;
	}

	// new line
	putchar(10);
	return;
}

int main()
{
	int count;

	setbuf(stdout, (char *)0x0);
	setbuf(stderr, (char *)0x0);
	scanf("%d", &count);
	while (true)
	{
		if (count == 0)
		{
			break;
		}
		count = count + -1;
		run();
	}
	return 0;
}
