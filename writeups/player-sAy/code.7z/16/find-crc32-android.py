#!/usr/bin/env python

# 参考：https://gist.github.com/Honno/4e6e4790e14c43bf5d6fa822fb56b6ea

import argparse
import sys
import binascii

SLEEP_TIME = 0.05

CRC32_BYTES = 4
CRC32_MAX = 2**32

TEMPLATE = None
DESTINATION = None
CRC_QUEUE = None

START_NUMBER = 3000000000

def crc_match(crc_and_new_infile):
    crc = crc_and_new_infile[0]
    new_infile = crc_and_new_infile[1]

    print("CRC {} ({}) is a match!".format(
        crc, crc.to_bytes(4, 'little').hex()))

    outfile = open(DESTINATION, 'wb')
    outfile.write(new_infile)
    outfile.close()
    print("Infile with self-referencing CRC written to {}".format(DESTINATION))
    sys.exit(0)

def bruteforce_crc_process():
    for crc in range(START_NUMBER, CRC32_MAX):
        if (crc % (1000000000/1000)) == 0:
            print(crc)

        crc_bytes = crc.to_bytes(4, 'little')

        # print("Trying CRC {} ({})".format(str(crc), crc_bytes.hex()))

        # new_infile = TEMPLATE[0:qpos] + crc_bytes + TEMPLATE[qpos +
        #                                                     CRC32_BYTES:pos] + crc_bytes + TEMPLATE[pos+CRC32_BYTES:]
        new_infile = TEMPLATE[0:14] + \
            crc_bytes + TEMPLATE[(14 + CRC32_BYTES):86] + \
            crc_bytes + TEMPLATE[(86 + CRC32_BYTES):253] + \
            crc_bytes + TEMPLATE[(253 + CRC32_BYTES):408] + \
            crc_bytes + TEMPLATE[(408 + CRC32_BYTES):]

        new_infile_crc = binascii.crc32(new_infile)
        # print("Modified source using CRC {} has the CRC value {}".format(str(crc), str(new_infile_crc)))

        if crc == new_infile_crc:
            return crc_match((crc, new_infile))
    sys.exit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument('infile')
    parser.add_argument('outfile')
    #parser.add_argument('pos', type=int)
    #parser.add_argument('qpos', type=int)

    #parser.add_argument('-s', '--start_at', type=int, default=0)

    args = parser.parse_args(sys.argv[1:])

    source = open(args.infile, 'rb')
    TEMPLATE = bytearray(source.read())
    source.close()
    if len(TEMPLATE) == 0:
        print("Infile contains no bytes")
        sys.exit(-1)

    DESTINATION = args.outfile
    try:
        dest = open(DESTINATION, 'w+')
        dest.close()
    except IOError:
        print("Cannot open {} outfile".format(DESTINATION))
        sys.exit(-1)

    bruteforce_crc_process()
