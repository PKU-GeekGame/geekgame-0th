
#!/usr/env/bin python

#flag = '.q~03QKLNSp"s6AQtEW<=MNv9(ZMYntg2N9hSe5=k'.encode()
#key = '.q~03QKLNSp"s6AQtEW<=MNv9(ZMYntg2N9hSe5=k'.encode()
#keyLength = 41

#def toi32(x):
#	x%=(2**32)
#	if x>=2**31:
#		return x-2**32
#	return x

#mem1952 = list(range(0, 96))

#var111 = 114514

##for i in range(96):
##	var111 = toi32(((var111 * 1919 + 7) % 334363) & (-1))
##	temp = var111 %

# label5
#mem1152 = [0] * keyLength
#for i in range(len(flag)):
#	temp113 = flag[i] - 32
#	if temp113 < 0 or temp113 >= 96:
#		print("ERROR")
#		exit(1)
#	mem1152[i] = ((mem1952[temp113] + i) % 96) & (-1) + 32

### label11
#mem2336 = [11, 26, 23, 36, 1, 31, 22, 10, 27, 4, 18, 30, 13, 19, 34, 24, 32, 21, 0, 39, 2, 5, 35, 14, 37, 40, 38, 17, 6, 28, 25, 33, 8, 12, 7, 16, 9, 29, 15, 20, 3]
#mem1552 = [0] * keyLength
#for i in range(len(flag)):
#	mem1552[mem2336[i]] = mem1152[i]


key = '.q~03QKLNSp"s6AQtEW<=MNv9(ZMYntg2N9hSe5=k'.encode()
#keyLength = 41
keyLength = len(key)
mem1952 = [22, 65, 61, 31, 87, 19, 38, 95, 4, 0, 54, 3, 55, 5, 9, 53, 11, 45, 67, 14, 40, 91, 42, 29, 18, 62, 39, 68, 88, 60, 83, 47, 58, 44, 63, 6, 20, 94, 90, 70, 23, 93, 43, 82, 1, 37, 41, 32, 80, 33, 85, 73, 86, 76, 35, 66, 12, 16, 78, 24, 7, 52, 17, 10, 25, 84, 74, 81, 59, 75, 2, 48, 27, 49, 26, 21, 57, 56, 92, 69, 8, 13, 89, 15, 50, 28, 30, 46, 64, 79, 51, 77, 34, 72, 36, 71]
mem2336 = [11, 26, 23, 36, 1, 31, 22, 10, 27, 4, 18, 30, 13, 19, 34, 24, 32, 21, 0, 39, 2, 5, 35, 14, 37, 40, 38, 17, 6, 28, 25, 33, 8, 12, 7, 16, 9, 29, 15, 20, 3]

mem1552 = key
mem1152 = [mem1552[mem2336[index]] for index in range(keyLength)]

def decodeMem1152Index(index):
	return mem1952.index((mem1152[index] - 32 - index) % 96) + 32

flag = bytes(decodeMem1152Index(index) for index in range(keyLength)).decode()
print(flag)
