#include <cstddef>
#include <cstdio>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <cctype>
#include <cstdlib>
#include <cmath>
#include <unistd.h>

struct EVP_PKEY_CTX;

//int init(EVP_PKEY_CTX *ctx)

//{
//  int extraout_EAX;

//  setbuf(stdin,(char *)0x0);
//  setbuf(stdout,(char *)0x0);
//  return extraout_EAX;
//}

//int main(EVP_PKEY_CTX *param_1)
int main()
{
	int inputNumber;
	void *name;
	char *inputBuffer;
	void *bigBox;
	void *biggerBox;

	//init(param_1);

	// 0x1000 = 4096
	name = malloc(0x1000);
	memcpy(name, "Gust", 5);
	printf("Hello, %s.\n", name);

	inputBuffer = (char *)malloc(0x1000);
	// 0x27 = 39
	memcpy(inputBuffer, "Now you can get a big box, what size?\n", 0x27);
	printf("%s", inputBuffer);

	// not null terminated
	read(0, inputBuffer, 0x1000);
	// return int (overflow)
	inputNumber = atoi(inputBuffer);

	// 4095 < N < 20481
	if ((0xfff < inputNumber) && (inputNumber < 0x5001))
	{
		bigBox = malloc((long)inputNumber);

		inputBuffer = (char *)malloc(0x1000);
		// 0x2a = 41
		memcpy(inputBuffer, "Now you can get a bigger box, what size?\n", 0x2a);
		printf("%s", inputBuffer);

		// not null terminated
		read(0, inputBuffer, 0x1000);
		inputNumber = atoi(inputBuffer);
		// 20479 < N < 40961
		if ((0x4fff < inputNumber) && (inputNumber < 0xa001))
		{
			biggerBox = malloc((long)inputNumber);

			inputBuffer = (char *)malloc(0x1000);
			// 0x1d = 29
			memcpy(inputBuffer, "Do you want to rename?(y/n)\n", 0x1d);
			printf("%s", inputBuffer);

			read(0, inputBuffer, 0x1000);
			if (*inputBuffer == 'y')
			{
				free(name);
				printf("Now your name is:%s, please input your new name!\n", name);
				read(0, name, 0x1000);
			}

			// Here inputBuffer/name is same
			inputBuffer = (char *)malloc(0x1000);
			// 0x3c = 60
			memcpy(inputBuffer, "Do you want to edit big box or bigger box?(1:big/2:bigger)\n", 0x3c);
			printf("%s", inputBuffer);

			// not null terminated
			read(0, inputBuffer, 0x1000);
			inputNumber = atoi(inputBuffer);
			printf("Let\'s edit, %s:\n", name); // printf("Let\'s edit, %s:\n", inputBuffer);
			if (inputNumber == 1)
			{
				read(0, bigBox, 0x1000);
			}
			else
			{
				read(0, biggerBox, 0x1000);
			}

			free(bigBox);
			free(biggerBox);
			printf("bye! %s", name);
		}
	}
	return 0;
}
