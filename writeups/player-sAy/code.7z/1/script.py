#!/usr/env/bin python

import string

cipher = "synt{J3ypbzr gb 0gu CXH ThThTh, rawbl gur tnzr!}"
flag = ""
shift = (ord("s") - ord("f"))
def decrypt(char):
	if char in string.ascii_lowercase:
		return chr(((ord(char) - ord("a") + 13) % 26) + ord("a"))
	elif char in string.ascii_uppercase:
		return chr(((ord(char) - ord("A") + 13) % 26) + ord("A"))
	else:
		return char
print("".join(decrypt(char) for char in cipher))
