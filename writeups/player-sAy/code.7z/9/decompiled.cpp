#include <cstddef>
#include <cstdio>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <cctype>

extern uint8_t dec64table[];

using uint = unsigned int;

char enc[1200];
int enclen;
uint8_t dec[700];
int declen;
char flag[100];

void read_flag()
{
	FILE *flagFileStream;
	size_t flagLength;

	flagFileStream = fopen("flag.txt", "r");
	// not null terminated?
	fread(flag, 1, 100, flagFileStream);
	flagLength = strlen(flag);
	printf("flag has %d bytes\n", flagLength & 0xffffffff);
	fclose(flagFileStream);
	return;
}

void print_hex(char *buffer, int length)
{
	int printIndex;

	printIndex = 0;
	while (printIndex < length)
	{
		putchar((int)buffer[printIndex]);
		printIndex = printIndex + 1;
	}
	return;
}

// (*localeTable)[code_num] & 0x2000

void b64decode(char *code, int code_len, uint8_t *result, int *result_len, int max_len = 700)

{
	uint8_t *result_next;
	uint8_t *result_next2;
	char *code_next;
	uint8_t base64_num1;
	uint8_t base64_num2;
	char code_num2;
	uint8_t base64_num3;
	int code_num;
	uint8_t *result_current;

	*result_len = max_len;
	if (code_len < 0)
	{
		code_len = code_len + 3;
	}
	result_current = result;

	// Error if code is too long
	if (max_len <= (code_len >> 2) * 3)
	{
		return;
	}

	while (true)
	{
		code_next = code + 1;
		code_num = (int)*code;
		// Return on valid null
		if (code_num == 0)
		{
			*result_len = (int)result_current - (int)result;
			return;
		}
		code = code_next;
		if (!isspace(code_num))
		{
			// Exit if base64 code not ascii
			if (0x7f < code_num)
			{
				return;
			}
			// to base64 num: 0-63
			base64_num1 = dec64table[code_num];
			// return if invalid
			//if (base64_num1 == -1)
			if (base64_num1 == 0xff)
			{
				return;
			}
			do
			{
				code_next = code + 1;
				code_num = (int)*code;
				code = code_next;
			} while (isspace(code_num));
			// Return on invalid null
			if (code_num == 0)
			{
				return;
			}
			base64_num2 = dec64table[code_num];
			if (base64_num2 == 0xff)
			{
				return;
			}
			result_next = result_current + 1;
			*result_current = base64_num1 << 2 | (uint8_t)((int)(uint)base64_num2 >> 4);
			do
			{
				code_next = code + 1;
				code_num = (int)*code;
				code = code_next;
			} while (isspace(code_num));
			// =
			if (code_num == 0x3d)
			{
				do
				{
					code_next = code + 1;
					code_num2 = *code;
					code = code_next;
				} while (isspace(code_num2));
				if (code_num2 != 0x3d)
				{
					return;
				}
				do
				{
					code_num = (int)*code;
					code = code + 1;
					result_current = result_next;
				} while (isspace(code_num));
				if (code_num == 0)
				{
					*result_len = (int)result_current - (int)result;
				}
				return;
			}
			if (0x7f < code_num)
			{
				return;
			}
			base64_num3 = dec64table[code_num];
			if (base64_num3 == 0xff)
			{
				return;
			}
			result_next2 = result_current + 2;
			*result_next = base64_num2 << 4 | (uint8_t)((int)(uint)base64_num3 >> 2);
			do
			{
				code_next = code + 1;
				code_num = (int)*code;
				code = code_next;
			} while (isspace(code_num));
			if (code_num == 0x3d)
			{
				do
				{
					code_num = (int)*code;
					code = code + 1;
					result_current = result_next2;
				} while (isspace(code_num));
				if (code_num == 0)
				{
					*result_len = (int)result_current - (int)result;
				}
				return;
			}
			if (0x7f < code_num)
			{
				return;
			}
			if (dec64table[code_num] == 0xff)
			{
				return;
			}
			result_current = result_current + 3;
			*result_next2 = base64_num3 << 6 | dec64table[code_num];
		}
	}
}

int main()

{
	setbuf(stdout, (char *)0x0);
	read_flag();
	printf("guess flag (base64): ");
	scanf("%s", flag);
	enclen = (int)strlen(enc);
	b64decode(enc, enclen, dec, &declen, 700);
	if (declen == 700)
	{
		puts("decode error");
	}
	else
	{
		int comprareResult = strcmp(flag, (char *)dec);
		if (comprareResult == 0)
		{
			puts("You already know the flag:");
			print_hex((char *)dec, declen);
		}
		else
		{
			puts("This is not the flag:");
			print_hex((char *)dec, declen);
		}
	}
	return 0;
}
