#!/usr/bin/env node

const axios = require(`axios`).default;

const url = `http://prob10.geekgame.pku.edu.cn`;

const main = async () => {
	try {
		const response = await axios.post(url, {
			action: null,
		});
		const {data, headers} = response;
		console.log(data);
		console.log(headers);
	} catch (error) {
		const {response} = error;
		const {data, headers} = response;
		console.log(data);
		console.log(headers);
	}
};

main();
