#include <stdio.h>

#define COMMAND(NAME) NAME ## in

int COMMAND(ma)() {
	printf("%s%s", "ma", "in");
}
