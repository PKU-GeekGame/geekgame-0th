#include <stdio.h>

#define FUNC(INITIAL) INITIAL ## ain

int FUNC(m)(void) {
	printf("%sain", "m");
	return 0;
}
