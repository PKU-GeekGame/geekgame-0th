#!/usr/bin/env node

const axios = require(`axios`).default;
const {JSDOM} = require(`jsdom`);

const fs = require(`fs`);
const path = require(`path`);
const queryString = require(`querystring`);

// Supply the session cookie (and perhaps the `UM_distinctid` cookie), for example: `session=cdcda57e-9ef5-428f-8014-dc152c08f209`
const cookies = ``;
const url = `http://prob11.geekgame.pku.edu.cn`;
const biggerEmojiMapFilename = `./map.json`;
const intervalMs = 1000;

const headers = {
	Cookie: process.env[`PKU_GEEK_GAME_COOKIES`] ?? cookies,
	//"User-Agent": `Mozilla/5.0 (X11; Linux x86_64; rv:89.0) Gecko/20100101 Firefox/89.0`,
};

const logError = (error) => {
	console.error(JSON.stringify(error));
	throw error;
};

const sleep = (ms) =>
	new Promise((resolve) => {
		setTimeout(resolve, ms);
	});

const deduplicateArray = (array) => [...new Set(array)];

let biggerEmojisMap = new Map();
try {
	biggerEmojisMap = new Map(
		JSON.parse(
			fs.readFileSync(path.join(__dirname, biggerEmojiMapFilename), {
				encoding: `utf-8`,
			}),
		),
	);
} catch {
	// Do nothing here
}

const updateBiggerEmojisMap = (emoji, biggerEmojis) => {
	const old = biggerEmojisMap.get(emoji);
	biggerEmojisMap.set(emoji, deduplicateArray([...old, ...biggerEmojis]));
};

const getBiggerEmojisThan = (emoji, level = 0) => {
	if (level >= 2 ** 17) {
		const error = {
			message: `Maximum recursion depth exceeded`,
			data: {
				emoji,
				level,
				biggerMap: [...biggerEmojisMap.entries()],
			},
		};
		logError(error);
	}

	const biggerEmojis = biggerEmojisMap.get(emoji);
	if (biggerEmojis === undefined) {
		if (emoji !== ``) {
			biggerEmojisMap.set(emoji, []);
		}
		return [];
	} else {
		if (biggerEmojis.includes(emoji)) {
			const error = {
				message: `Irreflexivity violation`,
				data: {
					emoji,
					biggerEmojis,
					biggerMap: [...biggerEmojisMap.entries()],
				},
			};
			logError(error);
		}

		return deduplicateArray(
			biggerEmojis.flatMap((biggerEmoji) => [
				biggerEmoji,
				...getBiggerEmojisThan(biggerEmoji, level + 1),
			]),
		);
	}
};

const getBiggerEmojis = (emojis) => {
	const biggerEmojiArrays = emojis.map(getBiggerEmojisThan);
	return emojis.filter((_emoji, index) => {
		const biggerEmojiArray = biggerEmojiArrays[index];
		return emojis.every((emoji) => !biggerEmojiArray.includes(emoji));
	});
};

const parseResponseHtml = (html) => {
	const {
		window: {document},
	} = new JSDOM(html);

	const message = document.body
		.querySelector(`div.alert.alert-info`)
		.innerHTML.trim();
	let correct;
	switch (message) {
		case `选项无效`:
			correct = null;
			break;
		case `回答错误，THIS IS BAD`:
			correct = false;
			break;
		case `回答正确，加油哦~`:
			correct = true;
			break;
		default:
			{
				const error = {
					message: `Unknown server response`,
					data: {
						message,
						html,
						biggerMap: [...biggerEmojisMap.entries()],
					},
				};
				logError(error);
			}
			correct = null;
			break;
	}
	const score = parseInt(
		document.body
			.querySelector(`div.progress > div.progress-bar`)
			.innerHTML.trim(),
	);
	const newEmojis = [
		...document.body.querySelectorAll(`form div.radio > label > input`),
	].map((input) => input.value);
	return {
		correct,
		score,
		newEmojis,
	};
};

const submitEmoji = async (emoji) => {
	const response = await axios.post(
		url,
		queryString.stringify({
			choice: emoji,
		}),
		{
			headers,
		},
	);
	const html = response.data;
	return html;
};

const submitBiggestEmoji = async (emojis) => {
	const biggerEmojis = getBiggerEmojis(emojis);
	if (biggerEmojis.length === 0) {
		const error = {
			message: `No bigger emoji found`,
			data: {
				emojis,
				biggerEmojis,
				biggerMap: [...biggerEmojisMap.entries()],
			},
		};
		logError(error);
	} else {
		const emojiChosen = biggerEmojis[0];
		const htmlResponse = await submitEmoji(emojiChosen);
		const {correct, score, newEmojis} = parseResponseHtml(htmlResponse);
		// I know that we can use `if (correct) {` here!
		if (correct === true) {
			emojis
				.filter((emoji) => emoji !== emojiChosen)
				.forEach((emoji) =>
					updateBiggerEmojisMap(emoji, [emojiChosen]),
				);
		} else if (biggerEmojis.length === 2) {
			const biggestEmoji = biggerEmojis[1];
			emojis
				.filter((emoji) => emoji !== biggestEmoji)
				.forEach((emoji) =>
					updateBiggerEmojisMap(emoji, [biggestEmoji]),
				);
		}
		fs.writeFileSync(
			path.join(__dirname, biggerEmojiMapFilename),
			JSON.stringify([...biggerEmojisMap.entries()]),
			{
				encoding: `utf-8`,
			},
		);
		console.log(`Current score: ${score}`);
		if (score >= 20) {
			console.log(htmlResponse);
		} else {
			await sleep(intervalMs);
			return await submitBiggestEmoji(newEmojis);
		}
	}
};

submitBiggestEmoji([``]);
