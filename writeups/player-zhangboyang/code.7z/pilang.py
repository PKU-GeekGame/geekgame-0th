import socket
import sys
import time
import base64
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('prob06.geekgame.pku.edu.cn',10006))
s.sendall(b'(token)\n')

time.sleep(1)

str = b'YWJj'*(699//3)+b'///'
print(str, len(str))
s.sendall(str+b'\n')


while True:
    b = s.recv(1)
    #print(b)
    if not len(b):
        break
    sys.stdout.buffer.write(b)
    sys.stdout.flush()

input()