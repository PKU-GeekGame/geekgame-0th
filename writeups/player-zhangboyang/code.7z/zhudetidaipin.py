import socket
import sys
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('prob04.geekgame.pku.edu.cn',10004))
s.sendall(b'(token)\n')

str = """
#include <stdio.h>
#define X ma ## in
int X()
{
    printf("ma" "in");
    return 0;
}
""".encode()
s.sendall(b'%d\n'%len(str))
s.sendall(str)

while True:
    b = s.recv(1)
    if not len(b):
        break
    sys.stdout.buffer.write(b)
