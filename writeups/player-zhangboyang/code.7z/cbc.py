import urllib.request
import urllib.parse
import base64

ticket0 = list(base64.b64decode("XldmmSC/Gd3Z+SaWXZ3dNkrE00HjpwUrr9gWNxylCFdQCniYwogX2nOoRkhBU8B3P0ZH6tTPlZvKW4tmisrZrnlfDl43Xt1wGu7TyBM4iAhLxiGK1GQloemHnB1c832Q"))

print(len(ticket0))

def test(ticket):
    #print(urllib.parse.quote_from_bytes(base64.b64encode(bytes(ticket))))
    rsp = urllib.request.urlopen("http://prob12.geekgame.pku.edu.cn/cbc/query-ticket?ticket="+urllib.parse.quote_from_bytes(base64.b64encode(bytes(ticket)))).read()
    #print(rsp)
    return not rsp.startswith(b'Error')

if False:
    ans = b''
    for n in range(1,1000):
        ticket = ticket0.copy()
        im = [0] * 16
        base = len(ticket0) - 16 * n
        if base == 0:
            break
        ticket = ticket[:base + 16]
        for pad in range(1, 17):
            pos = base - pad
            for guess in range(0, 256):
                ticket[pos] = guess
                if pad == 1 and bytes(ticket) == bytes(ticket0):
                    print("skip")
                    continue
                result = test(ticket)
                print(pad, guess, result, base64.b64encode(bytes(ticket)))
                if result:
                    im[16 - pad] = guess ^ pad
                    for i in range(16 - pad, 16):
                        ticket[base - 16 + i] = (pad + 1) ^ im[i]
                    break
            print(im)
        dec = [0] * 16
        for i in range(0, 16):
            dec[i] = (im[i] ^ ticket0[base - 16 + i])
        print(bytes(dec))
        ans = bytes(dec) + ans
        print(ans)
    exit(0)

target = b'stuid=1111111111|name=1|flag=True|code=zpj76wk9yhgg2zxu|timestamp=1621509231\x04\x04\x04\x04'
assert len(target) % 16 == 0

last = [0] * 16
ans = last.copy()
while len(target):
    block = target[-16:]
    target = target[:-16]
    print("last", last)
    print("block", block)
    im = [0] * 16
    iv = [0] * 16
    for pad in range(1, 17):
        for guess in range(0, 256):
            iv[16 - pad] = guess
            result = test(iv + last)
            if result:
                im[16 - pad] = guess ^ pad
                for i in range(16-pad, 16):
                    iv[i] = (pad + 1) ^ im[i]
                break
        print(im)
    for i in range(0, 16):
        last[i] = block[i] ^ im[i]
    ans = last + ans

print(base64.b64encode(bytes(ans)))