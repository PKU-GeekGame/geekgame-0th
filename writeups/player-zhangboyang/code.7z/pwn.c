#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void init()
{
  setbuf(stdin, 0LL);
  setbuf(stdout, 0LL);
}

void pp(const char *desc, void *p)
{
//  printf("[%s=%p]", desc,p);
}

char largearr[819200];

void *hdr;

unsigned char __attribute__ ((aligned(4096))) abc[100];

int main(int argc, const char **argv, const char **envp)
{
//void *test = malloc(0xabc);
  memset(largearr, 'z', sizeof(largearr));

  void *buf; // ST18_8
  void *v5; // ST18_8
  unsigned char *v6; // ST18_8
  void *v7; // ST18_8
  int v8; // ST0C_4
  int v9; // [rsp+4h] [rbp-2Ch]
  int v10; // [rsp+8h] [rbp-28h]
  void *name; // [rsp+10h] [rbp-20h]
  void *big; // [rsp+20h] [rbp-10h]
  void *bigger; // [rsp+28h] [rbp-8h]

pp("largearr", largearr);
pp("abc", abc);
  init();
  name = malloc(0x1000uLL);
pp("name", name);
//free(test);
  memcpy(name, "Gust", 5uLL);
  printf("Hello, %s.\n", name);
  
  buf = malloc(0x1000uLL);
pp("buf", buf);
  memcpy(buf, "Now you can get a big box, what size?\n", 0x27uLL);
  printf("%s", buf);
  read(0, buf, 0x1000uLL);


  v9 = atoi((const char *)buf);
  if ( v9 <= 4095 || v9 > 20480 )
    return 0;
  
  big = malloc(v9);
pp("big", big);
  
  v5 = malloc(0x1000uLL);
pp("v5", v5);
  memcpy(v5, "Now you can get a bigger box, what size?\n", 0x2AuLL);
  printf("%s", v5);
  read(0, v5, 0x1000uLL);
  
  v10 = atoi((const char *)v5);
  if ( v10 <= 20479 || v10 > 40960 )
    return 0;
  
  bigger = malloc(v10);
pp("bigger", bigger);
  
  v6 = malloc(0x1000uLL);
pp("v6", v6);
  memcpy(v6, "Do you want to rename?(y/n)\n", 0x1DuLL);
  printf("%s", v6);
  read(0, v6, 0x1000uLL);
  
  if ( *v6 == 'y' )
  {
    free(name);
    printf("Now your name is:%s, please input your new name!\n", name);
pp("name-2", ((void **)name)[-2]);
pp("name-1", ((void **)name)[-1]);
pp("name+0", ((void **)name)[0]);
pp("name+1", ((void **)name)[1]);
for (int i =0;i<100;i++) abc[i] = i;
//((void **)name)[1] = &abc[0];
hdr = ((void **)name)[0];
//pp("hdr-2", ((void **)hdr)[-2]);
//pp("hdr-1", ((void **)hdr)[-1]);
pp("hdr+0", ((void **)hdr)[0]);
pp("hdr+1", ((void **)hdr)[1]);
pp("hdr+2", ((void **)hdr)[2]);
pp("hdr+3", ((void **)hdr)[3]);
    read(0, name, 0x1000uLL);
//printf("%s", largearr);
  }
  
  v7 = malloc(0x1000uLL);
pp("v7", v7);
pp("hdr-1", ((void **)hdr)[-1]);
pp("hdr+0", ((void **)hdr)[0]);
pp("hdr+1", ((void **)hdr)[1]);
pp("hdr+2", ((void **)hdr)[2]);
pp("hdr+3", ((void **)hdr)[3]);
  memcpy(v7, "Do you want to edit big box or bigger box?(1:big/2:bigger)\n", 60uLL);
  printf("%s", v7);
for (int i = 0; i < 20; i++) { printf(".%02x", (unsigned) abc[i]); }
  read(0, v7, 0x1000uLL);
  
  v8 = atoi((const char *)v7);
  printf("Let's edit, %s:\n", name);
//printf("Let's edit, %s:\n", largearr);
  if ( v8 == 1 )
    read(0, big, 0x1000uLL);
  else
    read(0, bigger, 0x1000uLL);
 
//puts("before: free(big)");
  free(big);
//puts("after: free(big)");
//read(0, largearr, 0x1000uLL);
  free(bigger);
//puts("after: free(bigger)");
//read(0, largearr, 0x1000uLL);
  printf("bye! %s", name);

  return 0;
}
