import urllib.request
import urllib.parse
import base64
import binascii


def gen(name):
    rsp = urllib.request.urlopen("http://prob12.geekgame.pku.edu.cn/ecb/gen-ticket?name=%s&stuid=1111111111"%urllib.parse.quote(name)).read()
    rsp = rsp[44:]
    #print(rsp)
    return rsp[:rsp.find(b"</p>")]

def cut(b64ticket):
    split = []
    ticket = base64.b64decode(b64ticket)
    while ticket:
        block = ticket[:16]
        ticket = ticket[16:]
        split.append(binascii.hexlify(bytes(block)))
    return split

if False:
    offset = -1
    for i in range(1, 20):
        split=cut(gen("a"*i))
        print(split)
        if offset < 0 and split[1] == b'8fe7972ebc1e39aad2041e4388cd4fcf':
            offset = i
    print(offset)



#  stuid=1111111111|name=012345678|flag=False|code=zpj76wk9yhgg2zxu|timestamp=1621509231\x04\x04\x04\x04

#  stuid=1111111111|name=|flag=True|name=|code=aaaa|timestamp=1621509231\x04\x04\x04\x04
#  |               |               |               |                |
#  0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF|0123456789ABCDEF|0123456789ABCDEF

template = cut(gen("012345678"))
flag = cut(gen("|flag=True"))[1]
code = cut(gen("|code=aaaa"))[1]
print(flag, code)

answer = [template[0], flag, code] + template[4:]
print(answer)

print(base64.b64encode(binascii.unhexlify(b''.join(answer))))
