from flask import *
#from flag import getflag

app = Flask(__name__)
app.secret_key = 'oh you got it, one more step to get flag'

@app.route('/', methods=['GET', 'POST'])
def index():
    session['admin'] = True
    return "hello"
    
@app.route('/src')
def src():
    with open(__file__, encoding='utf-8') as f:
        src = f.read()
        src = src.replace(repr(app.secret_key), '***')
    
    resp = Response(src)
    resp.headers['content-type'] = 'text/plain; charset=utf-8'
    return resp
    
app.run('0.0.0.0', 5000, True)