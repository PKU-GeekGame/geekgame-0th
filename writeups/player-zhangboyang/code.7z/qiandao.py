import base64

s = base64.b64decode("c3ludHtKM3lwYnpyIGdiIDBndSBDWEggVGhUaFRoLCByYXdibCBndXIgdG56ciF9").decode()
print(s)
m = {}
for i in range(0,26):
    m[chr(ord('a') + (ord('f')-ord('s')+i) % 26)] = chr(ord('a') + i)
    m[chr(ord('A') + (ord('f')-ord('s')+i) % 26)] = chr(ord('A') + i)
print(m)
print(''.join(map(lambda x: m[x] if x in m else x, s)))