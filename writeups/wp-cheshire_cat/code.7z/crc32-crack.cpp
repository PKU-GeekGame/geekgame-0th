#include <iostream>
#include <cstdint>
#include <vector>
#include <iomanip>

using namespace std;

class Poly:public vector<bool>{
public:
    Poly():vector<bool>(){}

    Poly(uint32_t a):vector<bool>(){
        for (int i = 31; i >= 0; --i)
            push_back((a >> i) & 1);
    }

    int deg() const{
        int i = size()-1;
        while ((i >= 0) && (0 == at(i))) --i;
        return i;
    }
    
    void add(const Poly b){
        int l = b.deg();
        if ((int)size() < l+1) resize(l+1, 0);
        for (int i = 0; i <= l; ++i)
            (*this)[i] = (*this)[i] ^ b[i];
    }

    uint32_t dump(){
        uint32_t l = 0;
        for (int i = 0; (i < size()) && (i < 32); ++i)
            l |= at(i) << (31-i);
        return l;
    }
};

Poly mult(const Poly a, const Poly b){
    int n = a.deg(), m = b.deg();
    Poly ans;
    ans.resize((m+n+1>=0)?m+n+1:0, 0);
    for (int i = 0; i <= n; ++i)
        if (a[i])
            for (int j = 0; j <= m; ++j)
                ans[i+j] = ans[i+j] ^ b[j];
    return ans;
}

//devidend, divider, quotient, remainder
void divide(const Poly m, const Poly p, Poly & q, Poly & r){
    int l = p.deg(), k = m.deg();
    r = m;
    q.assign((k-l+1>=0)?k-l+1:0, 0);
    while (l <= k){
        for (int i = 0; i <= l; ++i)
            r[i+k-l] = r[i+k-l] ^ p[i];
        q[k-l] = 1;
        k = r.deg();
    }
    q.resize(q.deg()+1);
    r.resize(r.deg()+1);
}

//find p, q, r such that gcd(a, b) = r and a*p + b*q = r
void euclid(const Poly a, const Poly b, Poly & p, Poly & q, Poly & r){
    Poly a1 = a, b1 = b, q1, r1;
    Poly x, y, z, w; 
    // represents a matrix (x, y) , multiplied each time by (0,  1) from the left
    //                     (z, w)                           (1, q1)
    x.assign(1, 1); w.assign(1, 1);
    while (b1.deg() >= 0){
        divide(a1, b1, q1, r1);
        x.swap(z); y.swap(w);
        z.add(mult(x, q1));
        w.add(mult(y, q1));
        a1 = b1; b1 = r1;
    }
    r = a1;
    p = x;
    q = y;
}

int main(){
    // all 32 bit numbers have LSB at x^31 and MSB at x^0
    uint32_t c0 = 0x4a244bd9; //crc32 when filled with 0x00000000
    uint32_t c1 = 0x11d69b22; //crc32 when filled with 0x80000000
    uint32_t A = c0;
    uint32_t K = c0 ^ c1 ^ 0x80000000;
    uint32_t L = 0x7fc31077;
    uint32_t Q = 0xedb88320; //polynomial
    Poly a(A), k(K), q(Q), l(L);
    q.push_back(1);

    cout << "A: ";
    for (auto i : a) cout << i << " ";
    cout << endl;

    cout << "K: ";
    for (auto i : k) cout << i << " ";
    cout << endl;

    cout << "Q: ";
    for (auto i : q) cout << i << " ";
    cout << endl;

    cout << "L: ";
    for (auto i : l) cout << i << " ";
    cout << endl;

    Poly s, t, r;
    euclid(q, k, s, t, r);
    
    cout << "s: ";
    for (auto i : s) cout << i << " ";
    cout << endl;

    cout << "t: ";
    for (auto i : t) cout << i << " ";
    cout << endl;

    cout << "gcd: ";
    for (auto i : r) cout << i << " ";
    cout << endl;

    Poly check = mult(q, s);
    check.add(mult(k, t));

    cout << "check qs+kt: ";
    for (auto i : check) cout << i << " ";
    cout << endl;

    Poly temp = mult(a, t), ans;
    divide(temp, q, check, ans);

    cout << "answer: ";
    for (auto i : ans) cout << i << " ";
    cout << endl;
    
    uint32_t crc = ans.dump();
    cout << "hex    : " << setfill('0') << setw(8) << setbase(16) << crc << endl;
    cout << "hex rev: " << setfill('0') << setw(8) << setbase(16) << (crc ^ 0xffffffff) << endl;
/*
    //l = ans;
    temp = a; temp.add(mult(k, l));

    cout << "temp   : ";
    for (auto i : temp) cout << i << " ";
    cout << endl;
    
    divide(temp, q, check, ans);

    cout << "testcrc: ";
    for (auto i : ans) cout << i << " ";
    cout << endl;

    uint32_t testcrc = ans.dump();
    cout << "testcrc: " << setfill('0') << setw(8) << setbase(16) << (testcrc ^ 0xffffffff) << endl;
*/
    return 0;
}
