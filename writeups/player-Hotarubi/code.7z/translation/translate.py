class translator:
    def __init__ (self, cipher, table_len=16, max_wordlength=8):
        self.cipher = cipher;
        self.cipher_len = len(cipher);
        self.table = [];
        self.table_len = table_len;
        self.max_wordlength=max_wordlength;
    
    def walk (self, start_offset=0):
        return;
