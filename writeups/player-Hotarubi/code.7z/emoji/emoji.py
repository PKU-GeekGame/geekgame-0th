import random
import time
import requests
from bs4 import BeautifulSoup;
import pickle

class bank:

    def __init__(self) -> None:
        self.bdict = dict();
    
    def pushnew(self, char):
        if char in self.bdict:
            return
        randominit = random.random();
        self.bdict[char] = randominit;
    
    def query(self, *chars):
        best = max(chars, key = lambda x:self.bdict[x]);
        return best;
    
    def punish(self, notbestchar, *chars):
        secondbest = sorted(chars, key = lambda x:self.bdict[x])[-2];
        self.bdict[notbestchar] = self.bdict[secondbest] - 1;

    def award(self, bestchar, *chars):
        s = self.bdict[bestchar];
        for i in self.bdict:
            if self.bdict[i] > s:
                self.bdict[i] += 3;
        self.bdict[bestchar] += 3;

    
mybank = bank();

webendpoint = 'http://prob11.geekgame.pku.edu.cn';
headers = {'Cookie': 'session=7939375b-bd01-4372-a010-892540f5e2e8'};

r = requests.get(webendpoint, headers=headers);
soup = BeautifulSoup(r.text, features="html.parser");


for rounds in range(20000):
    time.sleep(1);
    options = [option['value'] for option in soup.find_all('input')];
    for option in options:
        mybank.pushnew(option);
    
    best = mybank.query(*options);
    r = requests.post(webendpoint, data={'choice': best}, headers=headers);
    soup = BeautifulSoup(r.text, features="html.parser");
    print (soup.find_all('div', class_='progress')[0].text.strip(), len(mybank.bdict), len(options), rounds);
    status = soup.find_all('div', class_='alert alert-info')[0].text.strip();
    print(status)
    if status == '回答错误，THIS IS BAD' :
        mybank.punish(best, *options);
        print (best, mybank.bdict[best]);
    elif status == '回答正确，加油哦~':
        mybank.award(best, *options);
        print (best, mybank.bdict[best]);
    else:
        break;

print (mybank.bdict);
print (r.text);

output_hal = open("1.pkl", 'wb')
str = pickle.dumps(mybank);
output_hal.write(str);
output_hal.close();


output_hal = open("2.pkl", 'wb')
str = pickle.dumps(r);
output_hal.write(str);
output_hal.close();