g_18 = 4982;
g_19 = 5400;
g_20 = 4986;
g_21 = 5000;

len(key) = 41;

key = [46, 113, 126, 48, 51, 81, 75, 76, 78, 83, 112, 34, 115, 54, 65, 81, 116, 69, 87, 60, 61, 77, 78, 118, 57, 40, 90, 77, 89, 110, 116, 103, 50, 78, 57, 104, 83, 101, 53, 61, 107];

*(4982) = len(inv);
*(5000+) = inv;
*(1952) = str9;
*(1152) = str1;
*(2336) = str3;
*(1552) = str5;

l_116 = g_16;
g_16 += 16;
g_17 = g_16;

// overflow ???

w=b=l_0=0;
w = 114514;

for (i = 0; i < 96; i++){
    str9[i] = i;
}

for(i = 1; i < 96; i++) {
    w = v16 = ((1919 * w + 7) mod 334363)&(-1);
    b = v19 = (w mod i) & (-1);
    
    l_114 = str9[b];
    str9[b] = str9[i];
    str9[i] = l_114;
}

for (i = 0; i < len(inv); i++){
    b = inv[i] - 32;
    if (b<0 or b>=96) { // 32<=inv[i]<128
        l_115 = 10;
        break;
    }
    str1[i] = ((str9[b] + i) mod 96) & (-1) + 32;
}

if (l_115 == 10) {
    g_16 = l_116;
    return -1;
}

for (i = 0; i < len(inv); i++) {
    str3[i] = i;
}

for (i = 1; i < len(inv); i++) {
    w = v_74 = ((1919*w + 7) mod 334363) & (-1);
    b = v_77 = (w mod i) & (-1);

    l_114 = str3[b];
    str3[b] = str3[i];
    str3[i] = l_114;
}

for (i = 0; i < len(inv); i++) {
    str5[str3[i]] = str1[i];
}


if (len(inv) != len(key)) {
    g_16 = l_116;
    return 0;
}

for (i = 0; ; i++) {
    if (i >= len(inv)) {
        l_115 = 28
        break;
    }
    if (str5[i] != key[i]) {
        l_115 = 26;
        break;
    }
}

if (l_115 == 26) {
    g_16 = l_116;
    return 0;
} else if (l_115 == 28) {
    g_16 = l_116;
    return 1;
} else {
    return 0;
}