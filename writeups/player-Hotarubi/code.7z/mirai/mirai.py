str9 = list(range(96));
w = 114514;
b = 0;

for i in range(1,96):
    w = ((1919*w+7)%334363)&(-1);
    b = (w%i)&(-1);
    str9[i], str9[b] = str9[b], str9[i];

print (str9);
str9_d = dict();
for i in range(96):
    str9_d[str9[i]]=i;

str3 = list(range(41));
for i in range(1,41):
    w = ((1919*w+7)%334363)&(-1);
    b = (w%i)&(-1);
    str3[i], str3[b] = str3[b], str3[i];

# print (str3);

str5 = [46, 113, 126, 48, 51, 81, 75, 76, 78, 83, 112, 34, 115, 54, 65, 81, 116, 69, 87, 60, 61, 77, 78, 118, 57, 40, 90, 77, 89, 110, 116, 103, 50, 78, 57, 104, 83, 101, 53, 61, 107];

str1 = [-1 for i in range(41)];
for i in range(41):
    str1[i] = str5[str3[i]];

# print(str1);

str9b = [-1 for i in range(41)];

for i in range(41):
    str9b[i] = (str1[i] - 32 - i)%96;

inv = [chr(32+str9_d[str9b[i]]) for i in range(41)];
print ("".join(inv));