#include <stdio.h>
#include <zlib.h>

int main() {
    FILE* fp;
    fp = fopen("quine.zip", "rb");
    char buffer[543];

    fread(buffer, 1, 542 , fp);

    fclose(fp);

    /*
    for (char a = 0; a<255; a++){
        buffer[14] = buffer[86] = buffer[253] = buffer[408] = a;
        for (char b = 0; b<255; b++) {
            buffer[15] = buffer[87] = buffer[254] = buffer[409] = b;
            for (char c = 0; c<255; c++) {
                buffer[16] = buffer[88] = buffer[256] = buffer[410] = c;
                for (char d = 0; d < 255; d++){
                    buffer[17] = buffer[89] = buffer[257] = buffer[411] = d;
                    
                }
            }
        }
    }
    */
   unsigned j = 2503926738;
   if (crc32(0L, buffer, 542)==j)  printf("%u\n", j);

   for (unsigned i = 0; i < 4294967295; i++) {
       *(unsigned*)(buffer+14) = i;
       *(unsigned*)(buffer+86) = i;
       *(unsigned*)(buffer+253) = i;
       *(unsigned*)(buffer+408) = i;
       if (crc32(0L, buffer, 542)== i) {
           printf("%u\n", i);
           break;
       }
       if (i%16219136==0) {
           printf("%u\n", i);
       }
   }
}